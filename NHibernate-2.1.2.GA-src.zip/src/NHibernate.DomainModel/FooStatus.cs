using System;

namespace NHibernate.DomainModel
{
	[Serializable]
	public enum FooStatus
	{
		OFF,
		ON
	}
}