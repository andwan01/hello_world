namespace NHibernate.Test.DynamicEntity
{
	public interface Company
	{
		long Id { get; set;}
		string Name { get; set;}
	}
}