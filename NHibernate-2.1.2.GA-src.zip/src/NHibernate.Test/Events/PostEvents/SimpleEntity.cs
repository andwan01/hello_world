namespace NHibernate.Test.Events.PostEvents
{
	public class SimpleEntity
	{
		public virtual int Id { get; set; }
		public virtual string Description { get; set; }
	}
}