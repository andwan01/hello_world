namespace NHibernate.Test.Events.Collections
{
	public interface IEntity
	{
		long Id { get; set;}
	}
}