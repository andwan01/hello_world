namespace NHibernate.Test.Events.Collections
{
	public interface IChild
	{
		string Name { get; set;}
	}
}