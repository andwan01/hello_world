namespace NHibernate.AdoNet.Util
{
	public interface IFormatter
	{
		string Format(string source);
	}
}