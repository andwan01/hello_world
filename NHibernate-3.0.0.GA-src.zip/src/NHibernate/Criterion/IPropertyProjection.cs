namespace NHibernate.Criterion
{
	public interface IPropertyProjection
	{
		string PropertyName { get; }
	}
}