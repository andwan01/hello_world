Castle.DynamicProxy
- Proxy Generation Library
- runtime, required

Iesi.Collection
- Implementation of Set based collections
- runtime, required

log4net
- Logging Library.
- runtime, required

nunit.framework
- NUnit Testing Library.
- buildtime